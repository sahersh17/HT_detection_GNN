module tt_um_four_bit_cpu_top_level(
    input  wire [7:0] ui_in,    // Dedicated inputs
    output wire [7:0] uo_out,   // Dedicated outputs
    input  wire [7:0] uio_in,   // IOs: Input path
    output wire [7:0] uio_out,  // IOs: Output path
    output wire [7:0] uio_oe,   // IOs: Enable path (active high: 0=input, 1=output)
    input  wire       ena,      // will go high when the design is enabled
    input  wire       clk,      // clock
    input  wire       rst_n     // reset_n - low to reset
);
    // ###############################################
    //                  PARAMETERS
    // ###############################################
    localparam OPERATION_CODE_WIDTH = 3;
    localparam CRA_BIT_NUMB = 4;
    localparam REGISTER_WIDTH = 4;
    localparam MEMORY_ADDRESS_WIDTH = 4;
    localparam MEMORY_REGISTERS = 16;
    localparam REGISTER_COUNT = 2;

    localparam UART_DATA_LENGTH = 8;
    localparam RX_COUNTER_BITWIDTH = 3;
    localparam BAUD_COUNTS_PER_BIT = 521; // for 10MHz clk
    localparam BAUD_RATE_COUNTER_BITWIDTH = 10; //2^10 0 1024

    // ###############################################
    //              CONNECTING SIGNALS
    // ###############################################
    assign uio_oe[7:0] = 8'b11111111; // all outputs

    wire ui_in_4_sync;
    wire ui_in_5_sync;
    wire ui_in_6_sync;
    wire ui_in_7_sync;

    wire ui_in_2_sync;
    wire ui_in_3_sync;

    // ###############################################
    // Synchronizers for input signals
    // ###############################################

    input_synchronizer #(
        .REGISTER_COUNT(REGISTER_COUNT)
    ) is_in_4 (
        .clk_i(clk),
        .reset_i(~rst_n),
        .input_i(ui_in[4]),
        .output_o(ui_in_4_sync)
    );

    input_synchronizer #(
        .REGISTER_COUNT(REGISTER_COUNT)
    ) is_in_5 (
        .clk_i(clk),
        .reset_i(~rst_n),
        .input_i(ui_in[5]),
        .output_o(ui_in_5_sync)
    );

    input_synchronizer #(
        .REGISTER_COUNT(REGISTER_COUNT)
    ) is_in_6 (
        .clk_i(clk),
        .reset_i(~rst_n),
        .input_i(ui_in[6]),
        .output_o(ui_in_6_sync)
    );

    input_synchronizer #(
        .REGISTER_COUNT(REGISTER_COUNT)
    ) is_in_7 (
        .clk_i(clk),
        .reset_i(~rst_n),
        .input_i(ui_in[7]),
        .output_o(ui_in_7_sync)
    );

    input_synchronizer #(
        .REGISTER_COUNT(REGISTER_COUNT)
    ) is_in_2 (
        .clk_i(clk),
        .reset_i(~rst_n),
        .input_i(ui_in[2]),
        .output_o(ui_in_2_sync)
    );

    input_synchronizer #(
        .REGISTER_COUNT(REGISTER_COUNT)
    ) is_in_3 (
        .clk_i(clk),
        .reset_i(~rst_n),
        .input_i(ui_in[3]),
        .output_o(ui_in_3_sync)
    );
    
    cpu #(
        .CRA_BIT_NUMB(CRA_BIT_NUMB),
        .OPERATION_CODE_WIDTH(OPERATION_CODE_WIDTH),
        .REGISTER_WIDTH(REGISTER_WIDTH),
        .MEMORY_ADDRESS_WIDTH(MEMORY_ADDRESS_WIDTH),
        .MEMORY_REGISTERS(MEMORY_REGISTERS),

        .UART_DATA_LENGTH(UART_DATA_LENGTH),
        .RX_COUNTER_BITWIDTH(RX_COUNTER_BITWIDTH),
        .BAUD_COUNTS_PER_BIT(BAUD_COUNTS_PER_BIT),
        .BAUD_RATE_COUNTER_BITWIDTH(BAUD_RATE_COUNTER_BITWIDTH)
    ) dut (
        .clk_i(clk),
        .reset_i(~rst_n),

        // IN
        .in_pins_i({ui_in_7_sync, ui_in_6_sync, ui_in_5_sync, ui_in_4_sync}),
        .next_data_strb_o(uio_out[0]),
        // OUT
        .out_pins_o(uo_out[3:0]),
        .data_valid_strb_o(uio_out[1]),

        // INST REG
        .instr_reg_o(uo_out[7:4]),
        
        // Status Flags
        .programm_o(uio_out[2]),
        .fetch_instr_o(uio_out[3]),
        .decode_o(uio_out[4]),
        .fetcho_op_o(uio_out[5]),
        .fetch_mdr_o(uio_out[6]),
        .execute_o(uio_out[7]),

        // Programmer
        .p_programm_i(ui_in_2_sync),

        // UART RX
        .rx_i(ui_in_3_sync)
    );
endmodule